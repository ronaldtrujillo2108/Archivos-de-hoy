# Este es un comentario. El intérprete lo ignora.
# La función print() muestra un mensaje en la pantalla.
print("¡Hola, Mundo!")