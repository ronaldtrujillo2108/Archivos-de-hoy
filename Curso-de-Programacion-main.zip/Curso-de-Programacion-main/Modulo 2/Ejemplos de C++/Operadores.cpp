int a = 10, b = 3;
int suma = a + b;   // 13
int resto = a % b;  // 1
bool esMayor = a > b; // true