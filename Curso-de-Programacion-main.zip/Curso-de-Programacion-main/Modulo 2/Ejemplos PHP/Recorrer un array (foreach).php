<?php
$colores = ["Rojo", "Verde", "Azul"];
// "Por cada elemento en $colores, asígnalo temporalmente a la variable $color"
foreach ($colores as $color) {
    echo "Color actual: " . $color . "\n";
}
?>