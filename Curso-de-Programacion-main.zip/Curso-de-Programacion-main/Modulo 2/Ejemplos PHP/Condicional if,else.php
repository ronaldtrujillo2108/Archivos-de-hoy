<?php
echo "## 2. Ejemplo de if / else ##\n";

$edad = 17;

if ($edad >= 18) {
    echo "Eres mayor de edad. Puedes ingresar.\n";
} else {
    echo "No eres mayor de edad. Acceso denegado.\n";
}
echo "\n";
?>