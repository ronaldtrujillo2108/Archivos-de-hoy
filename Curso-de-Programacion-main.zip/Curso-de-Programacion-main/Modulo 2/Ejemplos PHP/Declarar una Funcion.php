<?php
// Aquí definimos nuestra herramienta, pero todavía no la usamos.
function mostrarSaludo() {
    echo "¡Hola! Bienvenido a mi sitio web desde Maracaibo.\n";
}

// Ahora, usamos la herramienta llamándola por su nombre.
// Esto ejecuta el código que está dentro de la función.
mostrarSaludo(); 
?>