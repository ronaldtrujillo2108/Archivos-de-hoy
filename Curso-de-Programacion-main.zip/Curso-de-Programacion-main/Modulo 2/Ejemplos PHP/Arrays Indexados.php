<?php
$frutas = ["Manzana", "Naranja", "Fresa", "Pera"];

// Para obtener un valor, usamos el nombre del array y el índice entre corchetes [].
echo "El elemento en la posición 0 es: " . $frutas[0] . "\n"; 
echo "El elemento en la posición 2 es: " . $frutas[2] . "\n"; 
?>