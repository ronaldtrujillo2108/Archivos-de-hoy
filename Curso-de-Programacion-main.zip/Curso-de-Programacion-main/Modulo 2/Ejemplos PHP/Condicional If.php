<?php
echo "## 1. Ejemplo de if ##\n";

$temperatura = 32; // Grados Celsius

// Este bloque solo se ejecutará si $temperatura es mayor que 30
if ($temperatura > 30) {
    echo "Hace mucho calor. ¡Recuerda mantenerte hidratado!\n";
}

echo "Revisión del clima finalizada.\n\n";
?>